const appSettings = {
  DefaultApiUrl: "http://localhost:58211/api",
};
export default appSettings;
