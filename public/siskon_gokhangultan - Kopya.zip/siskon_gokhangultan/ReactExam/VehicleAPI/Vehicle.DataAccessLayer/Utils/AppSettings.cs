﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicle.DataAccessLayer.Utils
{
    public class AppSettings
    {
        public string MasterConnectionString { get; set; }
    }
}
